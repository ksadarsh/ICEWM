### IceWM install scripts

[os-depends.sh](https://ice-wm.org/scripts/os-depends.sh)
install missing IceWM package dependencies.
