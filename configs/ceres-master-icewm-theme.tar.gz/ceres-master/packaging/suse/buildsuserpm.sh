#!/bin/bash
set -e
_dir=`dirname "$(readlink -f "${0}")"`
_basedir=${_dir}
cd ${_basedir}
if [ -f ${_basedir}/../ceres-theme*.rpm ]; then
    rm -f ${_basedir}/../ceres-theme*.rpm
fi
if [ -f ${_basedir}/ceres-theme.spec ]; then
    rm -f ${_basedir}/ceres-theme.spec
fi
if [ -d ${_basedir}/ceres-theme ]; then
    rm -rf ${_basedir}/ceres-theme
fi
	mkdir -p ${_basedir}/ceres-theme/usr/share/themes
	cp -R ${_basedir}/../../ceres-gtk/* ${_basedir}/ceres-theme/usr/share/themes
	mkdir -p ${_basedir}/ceres-theme/usr/share/icons
	cp -R ${_basedir}/../../ceres-gtk-icons ${_basedir}/ceres-theme/usr/share/icons
#mate
	mkdir -p ${_basedir}/ceres-theme/usr/share/mate-panel/layouts
	cp -R ${_basedir}/../../ceres-mate/mate-panel/layouts/* ${_basedir}/ceres-theme/usr/share/mate-panel/layouts
	mkdir -p ${_basedir}/ceres-theme/usr/share/icons/mate-window-applets
	cp -R ${_basedir}/../../ceres-mate/mate-window-applets/* ${_basedir}/ceres-theme/usr/share/icons/mate-window-applets
	mkdir -p ${_basedir}/ceres-theme/usr/share/mate-background-properties
	cp ${_basedir}/../../ceres-mate/backgrounds/*.xml ${_basedir}/ceres-theme/usr/share/mate-background-properties
	mkdir -p ${_basedir}/ceres-theme/usr/share/backgrounds/ceres
	cp ${_basedir}/../../ceres-mate/backgrounds/*.png ${_basedir}/ceres-theme/usr/share/backgrounds/ceres
#slim
	mkdir -p ${_basedir}/ceres-theme/usr/share/slim/themes
	cp -R ${_basedir}/../../ceres-slim/* ${_basedir}/ceres-theme/usr/share/slim/themes
#plank
	mkdir -p ${_basedir}/ceres-theme/usr/share/plank/themes
	cp -R ${_basedir}/../../ceres-plank/* ${_basedir}/ceres-theme/usr/share/plank/themes
#icewm
	mkdir -p ${_basedir}/debian/ceres-theme/usr/share/icewm/themes
	cp -R ${_basedir}/../../ceres-icewm/* ${_basedir}/ceres-theme/usr/share/icewm/themes
	
#creating the spec file:
cat <<\EOFALL> ${_basedir}/ceres-theme.spec
Buildroot: BUILDROOT
Name: ceres-theme
Version: 1.20200503174158
Release: 1
Summary: Ceres theme
License: BSD 2 Clause
Requires: dmz-icon-theme-cursors, tango-icon-theme, google-roboto-fonts
Provides: ceres-theme = %version, mate-themes
Obsoletes: ceres-theme <= %version
Recommends: libgtk-2_0-0, libgtk-3-0, libgdk_pixbuf-2_0-0, gtk2-engine-mist, gtk2-engine-industrial, libcanberra-gtk2-module, libcanberra-gtk3-module, marco, xfwm4, mate-window-buttons-applet, mate-tweak, plank, icewm, slim
Group: System/X11
BuildArch: noarch

%define _rpmdir ../
%define _unpackaged_files_terminate_build 0
%define _source_payload w0.gzdio
%define _binary_payload w0.gzdio
%description
Ceres theme

%post

%postun

%files
%defattr(-,root,root,-)
#%doc COPYING ReadMe.md LICENSE
%{_datadir}/*
EOFALL

rpmbuild -bb --buildroot=${_basedir}/ceres-theme ${_basedir}/ceres-theme.spec
if [ -f ${_basedir}/../noarch/ceres-theme*.rpm ]; then
	mv ${_basedir}/../noarch/ceres-theme*.rpm ${_basedir}/..
	rm -rf ${_basedir}/../noarch ${_basedir}/ceres-theme.spec
fi
