#!/bin/bash
set -ex
_dir=`dirname "$(readlink -f "${0}")"`
_basedir=${_dir}
cd ${_basedir}/suse
chmod +x buildsuserpm.sh
fakeroot sh -c "${_basedir}/suse/buildsuserpm.sh"
