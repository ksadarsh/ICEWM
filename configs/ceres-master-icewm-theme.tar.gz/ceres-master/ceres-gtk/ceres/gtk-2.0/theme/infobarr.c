style"infobar"{
GtkInfoBar::action-area-border=5
GtkInfoBar::button-spacing=3
GtkInfoBar::content-area-border=4
GtkInfoBar::content-area-spacing=16}
widget_class"GtkInfoBar"style"infobar"

style"infobarlabel"{
font_name="bold"}
widget_class"*<GtkInfoBar>.<GtkLabel>"style"infobarlabel"

