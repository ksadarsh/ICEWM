style"filechooserdialog"{
xthickness=0
ythickness=0
bg[NORMAL]=shade(1.10,@bg_color)
bg[PRELIGHT]=shade(1.10,@bg_color)}
class"GtkFileChooserDialog"style"filechooserdialog"
widget_class"*GtkFileChooserDefault*GtkExpander"style"filechooserdialog"
widget_class"*GtkFileChooserDefault*GtkCheckButton"style"filechooserdialog"
widget_class"*GtkFileChooserDefault*GtkRadioButton"style"filechooserdialog"

style"filechoosertoolbar"{
GtkToolbar::shadow-type=GTK_SHADOW_NONE}
widget"*GtkFileChooserWidget*GtkToolbar"style"filechoosertoolbar"

