style"iconview"{
xthickness=0
ythickness=0
bg[SELECTED]=@selected_base_color
text[SELECTED]=@selected_text_color
GtkIconView::selection-box-alpha=40
GtkIconView::selection-box-color=@selected_base_color}
class "GtkIconView" style "iconview"
