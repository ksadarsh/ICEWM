style"colorselectiondialog"{
engine"pixmap"{
image{
function=FLAT_BOX
file="images/colorselectiondialog.svg"
border={5,5,5,5}
stretch=TRUE}}}
class"GtkColorSelectionDialog"style"colorselectiondialog"
