style"hpaned"{
xthickness=1
ythickness=1
engine"pixmap"{
image{
function=HANDLE
file="images/hpaned.svg"
border={3,4,0,0}
stretch=TRUE}}}
class"GtkHPaned"style"hpaned"

style"vpaned"{
xthickness=1
ythickness=1
engine"pixmap"{
image{
function=HANDLE
file="images/vpaned.svg"
border={0,0,4,3}
stretch=TRUE}}}
class"GtkVPaned"style"vpaned"

