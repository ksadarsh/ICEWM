style"entry"{
base[INSENSITIVE]=shade(0.98,@base_color)
GtkEntry::icon-prelight=0
GtkEntry::inner-border={1,1,3,3}
engine"pixmap"{
image{
function=SHADOW
shadow=IN
file="images/entry.svg"
border={3,3,3,3}
stretch=TRUE}}}
class"GtkEntry"style"entry"

style"entrymisc"{
engine"mist"{}}
widget"*GtkEntry*Image*"style"entrymisc"
