style"pcmanfm"{
bg[NORMAL]=@base_color}
widget"*FmMainWin"style"pcmanfm"
