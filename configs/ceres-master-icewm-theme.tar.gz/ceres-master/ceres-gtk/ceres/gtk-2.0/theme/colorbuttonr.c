style"colorbutton"{
GtkButton::inner-border={2,2,2,2}}
class "*GtkColorButton"style"colorbutton"
