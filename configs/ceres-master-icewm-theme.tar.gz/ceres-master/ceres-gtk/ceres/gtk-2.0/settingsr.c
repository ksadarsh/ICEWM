########################################################################
### Enable or disable Scrollbar steppers
### default is: NEXTSTYLE
########################################################################
style"scrollbarsteppers"{
GtkScrollbar::has-backward-stepper=0
GtkScrollbar::has-forward-stepper=1
GtkScrollbar::has-secondary-backward-stepper=1
GtkScrollbar::has-secondary-forward-stepper=0
}class"*"style"scrollbarsteppers"
