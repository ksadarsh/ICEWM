#!/bin/sh
set -e
_basedir="$(dirname "$(readlink -f "${0}")")"
cd "$_basedir"
if command -v yad >/dev/null 2>&1 ;then
	_dialog=yad
elif command -v kdialog >/dev/null 2>&1 ;then
	_dialog=kdialog
else
	_dialog=cli
fi
if [ "$_dialog" = "cli" ]; then
	if [ ! -t 0 ]; then
		x-terminal-emulator -e "$0"
		exit 0
	fi
fi
####################################################################
#checks!
#check if we have permissions
if [ ! -w "$_basedir" ]; then
	case $_dialog in
		yad)
			yad --image=dialog-information --text '\tYou dont have write permissions!\t' --button=OK:1 --on-top --center;;
		kdialog)
			kdialog --msgbox 'You dont have write permissions!' --title 'Error';;
		cli)
			printf 'You dont have write permissions!\n';;
	esac
	exit 1
fi
##common deps
(command -v sed >/dev/null 2>&1 && command -v tr >/dev/null 2>&1 && command -v find >/dev/null 2>&1 || _missingdep=true)
case $_missingdep in
	true)
		case $_dialog in
			yad)
				yad --image=dialog-information --text '\tYou either miss sed, tr, or find! Aborting!\t' --button=OK:1 --on-top --center;;
			kdialog)
				kdialog --msgbox 'You either miss sed, tr, or find! Aborting!' --title 'Error';;
			cli)
				printf "You either miss sed, tr, or find! Aborting!\n";;
		esac
	exit 1
	;;
esac
########################################################################

setscrollbarstyle_() {
	case $_dialog in
		yad)
			_scrollbarstyle=$(yad --form --text="Please select the style of your scrollbar steppers" --field ":cb" '1: Windows!^2: Platinum!3: None' --button=OK:1 --on-top --center --always-print-result | sed 's/[^0-9]*//g')
			;;
		kdialog)
			_output=$(kdialog --combobox "Please select the style of your scrollbar steppers" '1: Windows' '2: Platinum' '3: None')
			_scrollbarstyle=$(echo $_output|sed 's/[^0-9]*//g');;
		cli)
			cat <<\EOF

Please select the style of your scrollbar steppers:
	1: Windows
	2: Platinum
	3: None
	printf "Make your choice: [1,2,3]"
EOF
			read _scrollbarstyle
			sleep 5;;
	esac
	if [ "$(echo $_scrollbarstyle)" = "1" ]; then
			printf "Setting Windows-Style!\n"
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-backward-stepper/c\GtkScrollbar::has-backward-stepper=1' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-forward-stepper/c\GtkScrollbar::has-forward-stepper=1'{} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-secondary-backward-stepper/c\GtkScrollbar::has-secondary-backward-stepper=0' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-secondary-forward-stepper/c\GtkScrollbar::has-secondary-forward-stepper=0' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-backward-stepper:/c\-GtkScrollbar-has-backward-stepper:true;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-forward-stepper:/c\-GtkScrollbar-has-forward-stepper:true;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-secondary-backward-stepper:/c\-GtkScrollbar-has-secondary-backward-stepper:false;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-secondary-forward-stepper:/c\-GtkScrollbar-has-secondary-forward-stepper:false;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-backward-stepper/c\GtkScrollbar::has-backward-stepper=1' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-forward-stepper/c\GtkScrollbar::has-forward-stepper=1'{} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-secondary-backward-stepper/c\GtkScrollbar::has-secondary-backward-stepper=0' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-secondary-forward-stepper/c\GtkScrollbar::has-secondary-forward-stepper=0' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-backward-stepper:/c\-GtkScrollbar-has-backward-stepper:true;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-forward-stepper:/c\-GtkScrollbar-has-forward-stepper:true;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-secondary-backward-stepper:/c\-GtkScrollbar-has-secondary-backward-stepper:false;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-secondary-forward-stepper:/c\-GtkScrollbar-has-secondary-forward-stepper:false;' {} \;
			sleep 5
	elif [ "$(echo $_scrollbarstyle)" = "2" ]; then
			printf "Setting Platinum-Style!\n"
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-backward-stepper/c\GtkScrollbar::has-backward-stepper=0' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-forward-stepper/c\GtkScrollbar::has-forward-stepper=1' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-secondary-backward-stepper/c\GtkScrollbar::has-secondary-backward-stepper=1' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-secondary-forward-stepper/c\GtkScrollbar::has-secondary-forward-stepper=0' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-backward-stepper:/c\-GtkScrollbar-has-backward-stepper:false;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-forward-stepper:/c\-GtkScrollbar-has-forward-stepper:true;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-secondary-backward-stepper:/c\-GtkScrollbar-has-secondary-backward-stepper:true;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-secondary-forward-stepper:/c\-GtkScrollbar-has-secondary-forward-stepper:false;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-backward-stepper/c\GtkScrollbar::has-backward-stepper=0' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-forward-stepper/c\GtkScrollbar::has-forward-stepper=1' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-secondary-backward-stepper/c\GtkScrollbar::has-secondary-backward-stepper=1' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-secondary-forward-stepper/c\GtkScrollbar::has-secondary-forward-stepper=0' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-backward-stepper:/c\-GtkScrollbar-has-backward-stepper:false;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-forward-stepper:/c\-GtkScrollbar-has-forward-stepper:true;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-secondary-backward-stepper:/c\-GtkScrollbar-has-secondary-backward-stepper:true;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-secondary-forward-stepper:/c\-GtkScrollbar-has-secondary-forward-stepper:false;' {} \;
	elif [ "$(echo $_scrollbarstyle)" = "3" ]; then
			printf "Setting None-Style!\n"
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-backward-stepper/c\GtkScrollbar::has-backward-stepper=0' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-forward-stepper/c\GtkScrollbar::has-forward-stepper=0' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-secondary-backward-stepper/c\GtkScrollbar::has-secondary-backward-stepper=0' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar::has-secondary-forward-stepper/c\GtkScrollbar::has-secondary-forward-stepper=0' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-backward-stepper:/c\-GtkScrollbar-has-backward-stepper:false;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-forward-stepper:/c\-GtkScrollbar-has-forward-stepper:false;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-secondary-backward-stepper:/c\-GtkScrollbar-has-secondary-backward-stepper:false;' {} \;
			find $_basedir -type f -name settings.css -exec sed -i '/GtkScrollbar-has-secondary-forward-stepper:/c\-GtkScrollbar-has-secondary-forward-stepper:false;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-backward-stepper/c\GtkScrollbar::has-backward-stepper=0' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-forward-stepper/c\GtkScrollbar::has-forward-stepper=0' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-secondary-backward-stepper/c\GtkScrollbar::has-secondary-backward-stepper=0' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar::has-secondary-forward-stepper/c\GtkScrollbar::has-secondary-forward-stepper=0' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-backward-stepper:/c\-GtkScrollbar-has-backward-stepper:false;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-forward-stepper:/c\-GtkScrollbar-has-forward-stepper:false;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-secondary-backward-stepper:/c\-GtkScrollbar-has-secondary-backward-stepper:false;' {} \;
			find $_basedir -type f -name settingsr.c -exec sed -i '/GtkScrollbar-has-secondary-forward-stepper:/c\-GtkScrollbar-has-secondary-forward-stepper:false;' {} \;
	else
			printf "Ignoring - Not a valid choice!\n"
	fi
}


### start
while [ 1 ]; do
	case $_dialog in
		yad)
			_choice=$(yad --form --text="What would you like to do?" --field ":cb" '1: Change the scrollbarstyle!2: Exit this script' --button=OK:1 --on-top --center --always-print-result | sed 's/[^0-9]*//g')
			;;
		kdialog)
			_output=$(kdialog --combobox "What would you like to do?" '1: Change the scrollbarstyle' '2: Exit this script')
			_choice=$(echo $_output|sed 's/[^0-9]*//g');;
		cli)
			clear
			cat <<\EOF

What would you like to do?:

#1: Change the scrollbarstyle
#2: Exit this script"
EOF
			printf "Make your choice: [1,2]"
			read _choice;;
	esac
	case $_choice in
		1)
			clear
			sleep 1
			setscrollbarstyle_
			sleep 3
		;;
		2)
			printf "bye\n"
			sleep 0
			break
			exit 0
		;;
		*)
			printf '\nnothing more here\n'
		;;
	esac
done
