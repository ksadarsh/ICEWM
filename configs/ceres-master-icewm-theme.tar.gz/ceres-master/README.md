Ceres is a theme for MATE that is inspired by many old non-flat themes.

### Features:

* Made for the use with a mouse --> no big buttons or paddings or focus rectangles.
* Includes a GTK+3 theme
* Includes a GTK+2 theme that is only based on default gtk engines
* Includes a GTK1 color scheme
* Includes a [Marco](https://mate-desktop.org), [Xfwm](https://www.xfce.org/) and [IceWM](https://ice-wm.org/) theme
* Includes a Plank theme
* Includes a [SLiM](https://github.com/iwamatsu/slim/network) theme


#### Dependencies:

* [Roboto font](https://fonts.google.com/specimen/Roboto) (fallback font for all themes)
* [DMZ cursor theme](https://packages.debian.org/en/source/sid/dmz-cursor-theme) (fallback cursor set on all themes)
* [Tango icon theme](https://packages.debian.org/en/source/jessie/tango-icon-theme) (fallback icon set on all themes)
* GTK 3 theme needs GTK+ >=3.24
* GTK 2 theme needs the industrial, mist and the and pixbuf/pixmap engine(with SVG support).
* IceWM theme needs PNG support!


[![Preview](https://gitlab.com/sixsixfive/ceres/raw/master/.preview.small.png)](https://gitlab.com/sixsixfive/ceres/raw/master/.preview.png)

### Howto install?

#### Debian (exporting the path is a [new Frankenstein thing](https://bugs.debian.org/cgi-bin/bugreport.cgi?bug=918754) of Debian >=10)

NOTE: if you have sudo installed and configured you can also use the sudo way below.

```
su -c 'PATH=/usr/sbin:/sbin:/usr/local/sbin:$PATH apt install fakeroot git libfile-fcntllock-perl debhelper --no-install-recommends'
cd /tmp && git clone https://gitlab.com/sixsixfive/ceres.git
cd ceres/packaging
sh build_deb.sh
su -c 'PATH=/usr/sbin:/sbin:/usr/local/sbin:$PATH dpkg -i ceres-theme_*.deb;apt install -f --no-install-recommends'
```

#### *buntu(or debian with sudo)

```
sudo apt install fakeroot git libfile-fcntllock-perl debhelper --no-install-recommends
cd /tmp && git clone https://gitlab.com/sixsixfive/ceres.git
cd ceres/packaging
sh build_deb.sh
sudo sh -c 'dpkg -i ceres-theme_*.deb;apt install -f --no-install-recommends'
```

#### SuSE & Co

```
sudo zypper install fakeroot git rpmbuild
cd /tmp && git clone https://gitlab.com/sixsixfive/ceres.git
cd ceres/packaging
sh build_rpm.sh
sudo zypper install --no-recommends ceres-theme*.rpm
```

#### Any other

* 1: Copy the content of 'ceres-gtk' to your GTK/Xfwm/Metacity theme dirs (usually $SYSPREFIX/share/themes)

* 2: Copy the 'ceres-gtk-icons' folder to your icon theme dir (usually $SYSPREFIX/share/icons)

* 3: OPTIONAL: configure the scrollbars on the GTK themes(run the config.sh in the ceres gtk theme folder)

* 4: OPTIONAL: Install one of the additional themes

### FAQ

#### Howto disable the GTK+3 overlay scrollbars in X11

Note:

* Deb-like: SYSCONFIGDIR = /etc, XSESSIONCONFDIR = $(SYSCONFDIR)/X11/Xsession.d
* SuSE: SYSCONFIGDIR = /etc, XSESSIONCONFDIR = $(SYSCONFDIR)/X11/xinit/xinitrc.d

```
printf '\nexport GTK_OVERLAY_SCROLLING=0\nexport LIBOVERLAY_SCROLLBAR=0'>> $__XSESSIONCONFDIR__/99_disable_gtk_overlay_scrollbars
```

For root applications eg: Synaptic
```
printf '\nGTK_OVERLAY_SCROLLING=0\nLIBOVERLAY_SCROLLBAR=0'>> __$ SYSCONFIGDIR__/environment
```

#### Remove the GTK+3 Menubar background to make it look like the GTK2 theme

Just comment the line:

```
@import url("gtk-titlemenubar.css");
```

in your $theme/gtk-3.0/gtk.css

#### Howto set the GTK themes on non-GTK Environments like Openbox or IceWM

for GTK create a file ~/.gtkrc with something like:

```
include "$__SYSPREFIX__/share/themes/ceres/gtk/gtkrc"
```

for GTK+2 create a file ~/.gtkrc-2.0 with something like:

```
gtk-theme-name="ceres-nocomposite"
```

for GTK+3 create a file ${XDG_CONFIG_HOME}/gtk-3.0/settings.ini with something like:

```
[Settings]
gtk-theme-name=ceres-nocomposite
```
