V10lated from V10lator <v10lator@myway.de>, a modification of UltraBlack.

This theme is based on "UltraBlack" from Solisx7/BlueScorpio_7, see:
http://box-look.org/content/show.php/UltraBlack?content=106606

Changes from UltraBlack:
- Red to blue.
- Smaller window borders.
- Font handling.
- New "Start" icon.
- New LED-Clock.
- New background image.
- Greyed the icons on inactive windows out.
- Maybe something I don't remember right now. ;)


This theme was made on and for Netbooks.

Recomendet themes to use with it:
GTK: Oversword Dark, http://xfce-look.org/content/show.php/Oversword+Dark?content=105549
Icons: Shining Reprise, http://xfce-look.org/content/show.php/Shining+Reprise?content=123497

---------------------------------------------------------------------------------------

Startbutton for your distribution:

If you don't want the Tux-button but instead a button with the logo of your distribution
simply go into the folder taskbar inside of the theme folder, remove the link linux.xpm
and link one of the linux-*.xpm files to it.
here is an example for Ubuntu:
$ cd ~/.icewm/themes/V10lated/taskbar
$ rm linux.xpm
$ ln -s linux-ubuntu.xpm linux.xpm

after that reload the theme (or simply log out and then in again).

---------------------------------------------------------------------------------------

Changelog:

1.0.1: 
 - New restore button.
 - Changed image format for the background from xpm to png.
 - Changed the icon on the Start-button to a not distribution specific one.
   Will add more (distribution specific, based on the places/*-start-here.svg
   files from Shining Reprise) + a little "howto change them" later.

1.0.2:
 - Added distribution specific Start-buttons.
 - Wrote a Readme.txt and merged the Changelog.txt into it.
 - Translated the Readme.txt to Readme_de.txt.
 - New Window Borders (no more pixmaps for right, left, bottom).
 - New menu background (smaller pixmap).
 - New dialog background (no pixmap anymore).
 - Changed a few other colors (better interaktion with "Oversword Dark" GTK-Theme).
 - Modified the show desktop, windowlist, collapse and expand buttons.
