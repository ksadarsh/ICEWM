V10lated von V10lator <v10lator@myway.de>, eine Modifizierung von UltraBlack.

Dieses Theme basiert auf "UltraBlack" von Solisx7/BlueScorpio_7, siehe:
http://box-look.org/content/show.php/UltraBlack?content=106606

Änderungen gegenüber UltraBlack:
- Rot zu Blau.
- Dünnere Fensterrahmen.
- Schriftart-Handling.
- Neuer Start-Button.
- Neue LED-Uhr.
- Neues Hintergrundbild.
- Icons bei inaktiven Fenstern ausgegraut.
- Vielleicht noch irgendwas an das ich mich im Moment nicht erinnere. ;)


Dieses Theme wurde auf und für Netbooks entwickelt.

Empfohlene Themes für dieses:
GTK: Oversword Dark, http://xfce-look.org/content/show.php/Oversword+Dark?content=105549
Icons: Shining Reprise, http://xfce-look.org/content/show.php/Shining+Reprise?content=123497

---------------------------------------------------------------------------------------

Startbutton für deine Distribution:

Wenn du anstelle des Tux-Buttons lieber einen mit dem Logo deiner Distribution möchtest
gehe einfach in den Ordner taskbar (ein Unterordner des Themes), lösche den Link linux.xpm
und verlinke eine der linux-*.xpm Dateien dahin.
Hier ein Beispiel für Ubuntu:
$ cd ~/.icewm/themes/V10lated/taskbar
$ rm linux.xpm
$ ln -s linux-ubuntu.xpm linux.xpm

Danach das Theme neu laden (oder einfach aus- und wieder einloggen).

---------------------------------------------------------------------------------------

Changelog:

1.0.1: 
 - Neuer restore Button.
 - Bildformat für den Hintergrund von xpm auf png geändert.
 - Das Icon für den Start-Button auf ein nicht Distributionsabhängiges geändert.
   Ich werde später noch mehr (distributionsabhängige, basierend auf den
   places/*-start-here.svg Dateien von Shining Reprise) + ein kleines "howto change
   them" hinzufügen.

1.0.2:
 - Distributionsabhängige Start-Buttons hinzugefügt.
 - Readme.txt geschrieben und Changelog.txt dahin migriert.
 - Readme.txt nach Readme_de.txt übersetzt.
 - Neue Fensterrahmen (keine Pixmaps mehr für rechts, links, unten).
 - Neuer Menü Hintergrund (kleinere Pixmap).
 - Neuer Dialog Hintergrund (keine Pixmaps mehr).
 - Ein paar andere Farben geändert (bessere Interaktion mit dem "Oversword Dark" GTK-Theme).
 - Modifizierung der show desktop, windowlist, collapse und expand Buttons.
